if (typeof browser === "undefined") {
	var browser = chrome;
}
